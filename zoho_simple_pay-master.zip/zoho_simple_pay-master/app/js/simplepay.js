

let clientInput = document.getElementsByClassName("payrun-input")
let paymentRun = document.getElementsByClassName("paymentrun-input")
let paymentRunDiv = document.getElementById("paymentrun-div")
let textareaDiv = document.getElementById("textarea-div")
let paymentRunId = ""
let journalDate = ''
let payrunDetails = []
let allRecord = []
let unprocess = []

const simplepayClientGet = async () => {
    let client = {
        url: `https://api.payroll.simplepay.cloud/v1/clients/`,
        method: "GET",
        connection_link_name: "zbspsimplepayconnection"
    };

    ZFAPPS.request(client)
        .then(function (value) {
            try {
                let clients = JSON.parse(value.data.body);

                clientInput[0].textContent = "";
                clientInput[1].textContent = "";

                let selectedOption = document.createElement("option");
                selectedOption.textContent = "Select the Company";
                selectedOption.value = '';
                selectedOption.selected = true;
                clientInput[0].appendChild(selectedOption);
                clientInput[1].appendChild(selectedOption.cloneNode(true));

                clients.forEach((com) => {
                    let option = document.createElement("option");
                    option.textContent = com.client.name
                    option.value = com.client.id;

                    clientInput[0].appendChild(option);
                    clientInput[1].appendChild(option.cloneNode(true));
                });
            } catch (err) {
                console.error("Error parsing client data:", err);
            }
        })
        .catch(function (err) {
            console.error("Client request failed", err);
        });
}


const clientSelect = async (value) => {
    if (value != "") {
        await simplepayPaymentRunGet(value)
    }
    else {
        paymentRunDiv.style.visibility = "hidden"
        textareaDiv.style.visibility = "hidden"
        createJournalBtn.style.display = "none"
        ShowNotification("error", "Please select the Valid company")
    }
}

const companySelect = async (value) => {
    document.getElementById("waitingMessage").style.display = "none";
    document.getElementById("warning").style.display = "none"
    document.getElementById("table-container").style.display = "none";
    document.getElementById("pagination-unpro").style.display = "none"
    if (value != "") {
        document.getElementById("waitingMessage").style.display = "block";
        document.getElementById("waitingMessage").innerHTML = "Fetching... Please wait"
        await simplepayPaymentRunGet(value)

        await allJournalGet()
        if (unprocess.length > 0) {
            unprocess = unprocess.filter((data) => {
                let isData = allRecord.find((re) => `Simple Pay - ${data.payment_run.id}` === re.reference_number)
                if (!isData) {
                    return data
                }
            })
            await unprocessedList(unprocess, allRecord)
        }
        else {
            document.getElementById("waitingMessage").style.display = "none";
            document.getElementById("warning").style.display = "block"
            document.getElementById("warning").innerHTML = "No pay runs are available for creating journals in Zoho Books, as all pay runs have already been processed."
        }
    }
    else {
        paymentRunDiv.style.visibility = "hidden"
        textareaDiv.style.visibility = "hidden"
        ShowNotification("error", "Please select the Valid company")
    }
}

const unprocessedList = async (dataArray) => {
    let currentPage = 1;
    const rowsPerPage = 10;
    document.getElementById("waitingMessage").style.display = "none";
    document.getElementById("table-container").style.display = "block";
    dataArray.length > rowsPerPage ? document.getElementById("pagination-unpro").style.display = "block" :

        document.getElementById("pagination-unpro").style.display = "none"
    function displayTable(page) {
        const tableBody = document.getElementById("table-body");
        tableBody.innerHTML = "";
        const startIndex = (page - 1) * rowsPerPage;
        const endIndex = Math.min(startIndex + rowsPerPage, dataArray.length);

        for (let i = startIndex; i < endIndex; i++) {
            const row = document.createElement("tr");
            const data = dataArray[i].payment_run;

            row.innerHTML = `
      <td>${i + 1}</td>
      <td>${data.id}</td>
      <td>${data.wave_id}</td>
      <td>${data.period_end_date}</td>
      <td>${parseFloat(data.total.toFixed(2))}
    `;
            tableBody.appendChild(row);

        }

        document.getElementById("page-info").textContent = `Page ${page} of ${Math.ceil(dataArray.length / rowsPerPage)}`;
        document.getElementById("prev-btn").disabled = page === 1;
        document.getElementById("next-btn").disabled = page === Math.ceil(dataArray.length / rowsPerPage);
    }
    displayTable(currentPage);
    document.getElementById("prev-btn").onclick = () => changePage(-1);
    document.getElementById("next-btn").onclick = () => changePage(1);

    const changePage = (direction) => {
        currentPage += direction;
        displayTable(currentPage);
    }
}
const payrunSelect = async (value) => {

    let isRecord = false

    if (value !== "") {
        let splitValue = value.split(",")
        paymentRunId = splitValue[0]
        journalDate = splitValue[1]
        await allJournalGet()

        allRecord.find((re) => {
            if (`Simple Pay - ${paymentRunId}` === re.reference_number) {
                isRecord = true
            }
        })
        if (!isRecord) {
            createJournalBtn.innerHTML = "Next"
            createJournalBtn.style.display = "block"
        }
        else {
            ShowNotification("error", "This payrun already has an associated journal. Please choose a different one");
            createJournalBtn.innerHTML = "Next"
            createJournalBtn.style.display = "none"
        }

    }
    else {
        createJournalBtn.innerHTML = "Next"
        createJournalBtn.style.display = "none"
    }

}

const simplepayPaymentRunGet = async (id) => {
    let client = {
        url: `https://api.payroll.simplepay.cloud/v1/clients/${id}/payment_runs`,
        method: "GET",
        connection_link_name: "zbspsimplepayconnection"
    };
    await ZFAPPS.request(client)
        .then(async function (value) {

            try {
                let paymentruns = JSON.parse(value.data.body)

                unprocess = paymentruns
                if (paymentruns.length > 0) {
                    paymentRunDiv.style.visibility = "visible"
                    textareaDiv.style.visibility = "visible"
                    paymentRun[0].textContent = ""
                    let selectedOption = document.createElement("option")
                    selectedOption.textContent = "Select the Payrun"
                    selectedOption.value = ''
                    selectedOption.selected = true
                    paymentRun[0].appendChild(selectedOption)
                    await allJournalGet()
                    paymentruns.map((pay) => {
                        let isData = allRecord.find((re) => {
                            return `Simple Pay - ${pay.payment_run.id}` === re.reference_number
                        })
                        if (!isData) {
                            let option = document.createElement("option")
                            option.textContent = pay.payment_run.period_end_date
                            option.value = `${pay.payment_run.id},${pay.payment_run.period_end_date}`
                            paymentRun[0].appendChild(option)
                        }
                    })
                }
                else {
                    paymentRunDiv.style.visibility = "hidden"
                    textareaDiv.style.visibility = "hidden"
                    createJournalBtn.style.display = "none"
                    createJournalBtn.disabled = false
                    ShowNotification("error", "There is no payrun data avilable for the selected company")
                }


            }
            catch (err) {
                console.error(err);

            }
        })
        .catch(function (err) {
            console.error("client request failed", err);
        });
}


const getPayment = async () => {

    let textarea = document.getElementsByTagName("textarea")
    if (textarea[0].value != "") {
        createJournalBtn.innerHTML = 'Wait <span class="dots"><span class="dot"></span><span class="dot"></span><span class="dot"></span></span> ';
        createJournalBtn.disabled = true
        let pay = {
            url: `https://api.payroll.simplepay.cloud/v1/payment_runs/${paymentRunId}/accounting`,
            method: "GET",
            connection_link_name: "zbspsimplepayconnection"
        };
        ZFAPPS.request(pay)
            .then(async function (value) {

                try {
                    payrunDetails = JSON.parse(value.data.body)
                    await fieldmapCustomGet(payrunDetails)
                }
                catch (err) {
                    createJournalBtn.disabled = false
                    console.error(err);
                }
            })
    }
    else {
        createJournalBtn.disabled = false
        ShowNotification("error", "Note Field cannot be empty")

    }
}

const getPayslipForSpecificPayrun = async () => {
    let client = {
        url: `https://api.payroll.simplepay.cloud/v1/payment_runs/${paymentRunId}/payslips`,
        method: "GET",
        connection_link_name: "zbspsimplepayconnection"
    }

    return ZFAPPS.request(client)
        .then(function (value) {
            try {

                return JSON.parse(value.data.body);

            }
            catch (err) {
                console.error(err);

            }
        })
        .catch(function (err) {
            console.error("client request failed", err);
        });
}